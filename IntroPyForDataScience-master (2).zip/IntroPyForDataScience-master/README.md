# IntroPyForDataScience
Introduction to python for datascience @Epita.
